import "bootstrap/dist/css/bootstrap.min.css";
import { Button } from "reactstrap";
import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      //Creamos la lista de botones
      botones: [0, 0, 0, 0, 0],
      //Le ponemos un color de boton
      colores: ["Danger", "Primary", "Primary", "Primary", "Primary"],
    };
  }

  //Metodo el cual hace que suba el valor del boton
  aumenta(posicion) {
    this.setState((x) => {
      //Creamos una copia de botones y lo metemos en una constante
      const numero = [...x.botones];
      //Cambiamos el valor
      numero[posicion]++;
      //Ejecutamos el cambio
      return { botones: numero };
    });
  }

  //Renderizamos
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <Boton
            color={this.state.colores[0]}
            click={() => this.aumenta(0)}
            valor={this.state.botones[0]}
          />
          <Boton click={() => this.aumenta(1)} valor={this.state.botones[1]} />
          <Boton click={() => this.aumenta(2)} valor={this.state.botones[2]} />
          <Boton click={() => this.aumenta(3)} valor={this.state.botones[3]} />
          <Boton click={() => this.aumenta(4)} valor={this.state.botones[4]} />
        </header>
      </div>
    );
  }
}

function Boton(props) {
  return (
    <Button color={props.color} onClick={() => props.click()}>
      {props.valor}
    </Button>
  );
}

export default App;

