export default function Titulo(props) {
  return <h1>{props.titulo}</h1>;
}
